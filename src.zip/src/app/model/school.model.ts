export interface EventModel {
    name: String;
    date: Date;
    duration: Number;
    classes: Number[];
}