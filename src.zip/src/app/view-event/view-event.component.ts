import { Component, OnInit ,Input} from '@angular/core';
import { EventModel } from '../model/school.model';
@Component({
  selector: 'app-view-event',
  templateUrl: './view-event.component.html',
  styleUrls: ['./view-event.component.css']
})
export class ViewEventComponent implements OnInit {
  @Input() events: EventModel;
  constructor() { }

  ngOnInit() {
  }

}

